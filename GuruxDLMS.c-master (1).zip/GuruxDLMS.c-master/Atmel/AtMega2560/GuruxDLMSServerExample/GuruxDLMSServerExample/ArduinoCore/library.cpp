/*
 * ArduinoCore.cpp
 *
 * Created: 14.10.2018 19.51.21
 * Author : Mikko
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

