Credits
=======
  - Arduino client example write debug information modified to send message without second parameter.
    * [arslan437](https://github.com/arslan437)
  - hlp_int64ToString fails if value is negative.
    * [ashvin](http://www.gurux.fi/user/182348)
  - HLS authentication crash if CtoS is null.
    * [SEQRED S.A.](https://github.com/seqred-s-a)
  - dlms_handleDataNotification crash if sent time is used.
    * [SEQRED S.A.](https://github.com/seqred-s-a)
